var $ 		= require('jquery');
var Plane 	= require('./plane');

var plane = new Plane();
plane.start();