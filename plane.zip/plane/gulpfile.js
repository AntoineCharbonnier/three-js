var source = require('vinyl-source-stream');
var gulp = require('gulp');
var browserify = require('browserify');
var watchify = require('watchify');

var scriptsDir = './modules';
var buildDir = './app/js';

function buildScript(file, watch) {

  var props = {
    entries: [scriptsDir + '/' + file]
  };
  var bundler = watch ? watchify(props) : browserify(props);

  function rebundle() {
    console.log('update event', file);
    
    var stream = bundler.bundle();

    return stream.pipe(source(file))
          .pipe(gulp.dest(buildDir + '/'));
  }

  bundler.on('update', function() {
    rebundle();
  });

  
  return rebundle();
}


gulp.task('build', function() {
  return buildScript('main.js', false);
});


gulp.task('default', ['build'], function() {
  buildScript('main.js', true);
});